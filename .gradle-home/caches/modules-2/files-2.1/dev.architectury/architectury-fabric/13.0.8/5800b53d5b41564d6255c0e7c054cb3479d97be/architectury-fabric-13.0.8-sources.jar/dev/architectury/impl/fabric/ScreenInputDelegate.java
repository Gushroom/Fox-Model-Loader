/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.impl.fabric;

import dev.architectury.event.events.client.ClientScreenInputEvent;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;

public interface ScreenInputDelegate {
    class_437 architectury_delegateInputs();
    
    class DelegateScreen extends class_437 {
        private class_437 parent;
        
        public DelegateScreen(class_437 parent) {
            super(class_2561.method_43473());
            this.parent = parent;
        }
        
        @Override
        public boolean method_25400(char c, int i) {
            if (ClientScreenInputEvent.CHAR_TYPED_PRE.invoker().charTyped(class_310.method_1551(), parent, c, i).isPresent())
                return true;
            if (parent.method_25400(c, i))
                return true;
            return ClientScreenInputEvent.CHAR_TYPED_POST.invoker().charTyped(class_310.method_1551(), parent, c, i).isPresent();
        }
    }
}
