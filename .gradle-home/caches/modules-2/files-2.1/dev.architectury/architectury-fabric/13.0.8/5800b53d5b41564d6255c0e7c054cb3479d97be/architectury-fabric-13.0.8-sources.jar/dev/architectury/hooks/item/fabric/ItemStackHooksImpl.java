/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.item.fabric;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class ItemStackHooksImpl {
    public static boolean hasCraftingRemainingItem(class_1799 stack) {
        return stack.method_7909().method_7857();
    }
    
    public static class_1799 getCraftingRemainingItem(class_1799 stack) {
        if (!hasCraftingRemainingItem(stack)) return class_1799.field_8037;
        class_1792 item = stack.method_7909().method_7858();
        return item == null || item == class_1802.field_8162 ? class_1799.field_8037 : item.method_7854();
    }
}
