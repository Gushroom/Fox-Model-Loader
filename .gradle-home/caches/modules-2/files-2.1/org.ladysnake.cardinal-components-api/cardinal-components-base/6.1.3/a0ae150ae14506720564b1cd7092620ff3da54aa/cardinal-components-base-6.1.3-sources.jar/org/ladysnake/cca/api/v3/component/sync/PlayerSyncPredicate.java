/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2025 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.api.v3.component.sync;

import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Contract;

public interface PlayerSyncPredicate {
    @Contract(pure = true)
    boolean shouldSyncWith(class_3222 player);

    /**
     * If this method returns {@code true} and a client cannot handle a sync packet, they will be disconnected.
     * Otherwise, the sync will be skipped.
     */
    default boolean isRequiredOnClient() {
        return true;
    }

    static PlayerSyncPredicate all() {
        return p -> true;
    }

    static PlayerSyncPredicate only(class_1657 player) {
        return p -> p == player;
    }
}
