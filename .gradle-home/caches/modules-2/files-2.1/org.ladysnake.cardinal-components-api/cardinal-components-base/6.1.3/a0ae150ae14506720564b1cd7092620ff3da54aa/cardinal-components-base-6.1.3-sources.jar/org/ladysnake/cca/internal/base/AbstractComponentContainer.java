/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2025 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.internal.base;

import org.ladysnake.cca.api.v3.component.Component;
import org.ladysnake.cca.api.v3.component.ComponentContainer;
import org.ladysnake.cca.api.v3.component.ComponentKey;
import org.ladysnake.cca.api.v3.component.ComponentRegistry;
import org.ladysnake.cca.api.v3.component.CopyableComponent;

import java.util.Iterator;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_7225;

/**
 * Implementing class for {@link ComponentContainer}.
 */
public abstract class AbstractComponentContainer implements ComponentContainer {

    public static final String NBT_KEY = "cardinal_components";

    @Override
    public void copyFrom(ComponentContainer other, class_7225.class_7874 registryLookup) {
        for (ComponentKey<?> key : this.keys()) {
            Component theirs = key.getInternal(other);
            Component ours = key.getInternal(this);
            assert ours != null;

            if (theirs != null && !ours.equals(theirs)) {
                if (ours instanceof CopyableComponent<?>) {
                    @SuppressWarnings("unchecked") CopyableComponent<Component> copyable = (CopyableComponent<Component>) ours;
                    copyable.copyFrom(theirs, registryLookup);
                } else {
                    class_2487 tag = new class_2487();
                    theirs.writeToNbt(tag, registryLookup);
                    ours.readFromNbt(tag, registryLookup);
                }
            }
        }
    }

    /**
     * {@inheritDoc}
     *
     * @implSpec This implementation first checks if {@code tag} has a tag list
     * mapped to the "cardinal_components" key; if not it returns immediately.
     * Then it iterates over the list's tags, casts them to {@code NbtCompound},
     * and passes them to the associated component's {@code fromTag} method.
     * If this container lacks a corresponding component for a serialized component
     * type, the component tag is skipped.
     */
    @Override
    public void fromTag(class_2487 tag, class_7225.class_7874 registryLookup) {
        if(tag.method_10573(NBT_KEY, class_2520.field_33259)) {
            class_2499 componentList = tag.method_10554(NBT_KEY, class_2520.field_33260);
            for (int i = 0; i < componentList.size(); i++) {
                class_2487 nbt = componentList.method_10602(i);
                ComponentKey<?> type = ComponentRegistry.get(class_2960.method_60654(nbt.method_10558("componentId")));
                if (type != null) {
                    Component component = type.getInternal(this);
                    if (component != null) {
                        component.readFromNbt(nbt, registryLookup);
                    }
                }
            }
        } else if (tag.method_10573(NBT_KEY, class_2520.field_33260)) {
            class_2487 componentMap = tag.method_10562(NBT_KEY);

            for (ComponentKey<?> key : this.keys()) {
                String keyId = key.getId().toString();

                if (componentMap.method_10573(keyId, class_2520.field_33260)) {
                    Component component = key.getInternal(this);
                    assert component != null;
                    component.readFromNbt(componentMap.method_10562(keyId), registryLookup);
                    componentMap.method_10551(keyId);
                }
            }

            ComponentsInternals.logDeserializationWarnings(componentMap.method_10541());
        }
    }

    /**
     * {@inheritDoc}
     *
     * @implSpec This implementation first checks if the container is empty; if so it
     * returns immediately. Then, it iterates over this container's mappings, and creates
     * a compound tag for each component. The tag is then passed to the component's
     * {@link Component#writeToNbt(class_2487, class_7225.class_7874)} method. Every such serialized component is appended
     * to a {@code NbtCompound}, using the component type's identifier as the key.
     * The serialized map is finally appended to the passed in tag using the "cardinal_components" key.
     */
    @Override
    public class_2487 toTag(class_2487 tag, class_7225.class_7874 registryLookup) {
        if(this.hasComponents()) {
            class_2487 componentMap = null;
            class_2487 componentTag = new class_2487();

            for (ComponentKey<?> type : this.keys()) {
                Component component = type.getFromContainer(this);
                component.writeToNbt(componentTag, registryLookup);

                if (!componentTag.method_33133()) {
                    if (componentMap == null) {
                        componentMap = new class_2487();
                        tag.method_10566(NBT_KEY, componentMap);
                    }

                    componentMap.method_10566(type.getId().toString(), componentTag);
                    componentTag = new class_2487();   // recycle tag objects if possible
                }
            }
        }
        return tag;
    }

    @Override
    public String toString() {
        Iterator<ComponentKey<?>> i = this.keys().iterator();

        if (! i.hasNext()) {
            return "{}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('{');
        for (;;) {
            ComponentKey<?> key = i.next();
            Component value = key.getInternal(this);
            sb.append(key);
            sb.append('=');
            sb.append(value);

            if (! i.hasNext()) {
                return sb.append('}').toString();
            }

            sb.append(',').append(' ');
        }
    }
}
