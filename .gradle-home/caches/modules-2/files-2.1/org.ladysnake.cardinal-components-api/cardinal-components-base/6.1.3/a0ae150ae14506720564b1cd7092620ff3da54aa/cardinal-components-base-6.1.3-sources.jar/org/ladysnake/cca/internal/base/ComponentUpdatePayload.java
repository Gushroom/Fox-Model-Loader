/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2025 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.internal.base;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.ladysnake.cca.api.v3.component.ComponentKey;
import org.ladysnake.cca.api.v3.component.ComponentRegistry;

import java.util.Optional;

public record ComponentUpdatePayload<T>(
    class_9154<ComponentUpdatePayload<T>> id,
    T targetData,
    boolean required,
    class_2960 componentKeyId,
    class_9129 buf
) implements class_8710 {
    public static <T> class_8710.class_9154<ComponentUpdatePayload<T>> method_56483(String path) {
        return new class_8710.class_9154<>(class_2960.method_60655("cardinal-components", path));
    }

    public static <T> void register(class_9154<ComponentUpdatePayload<T>> id, class_9139<? super class_9129, T> targetDataCodec) {
        PayloadTypeRegistry.playS2C().register(id, codec(id, targetDataCodec));
    }

    public static <T> class_9139<class_9129, ComponentUpdatePayload<T>> codec(class_9154<ComponentUpdatePayload<T>> id, class_9139<? super class_9129, T> targetDataCodec) {
        return class_9139.method_56906(
            class_9139.method_56431(id), ComponentUpdatePayload::id,
            targetDataCodec, ComponentUpdatePayload::targetData,
            class_9135.field_48547, ComponentUpdatePayload::required,
            class_2960.field_48267, ComponentUpdatePayload::componentKeyId,
            MorePacketCodecs.REG_BYTE_BUF, ComponentUpdatePayload::buf,
            ComponentUpdatePayload::new
        );
    }

    public Optional<ComponentKey<?>> componentKey() {
        ComponentKey<?> key = ComponentRegistry.get(this.componentKeyId());
        if (key == null && this.required()) {
            throw new UnknownComponentException("Unknown component " + this.componentKeyId());
        }
        return Optional.ofNullable(key);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return id;
    }
}
