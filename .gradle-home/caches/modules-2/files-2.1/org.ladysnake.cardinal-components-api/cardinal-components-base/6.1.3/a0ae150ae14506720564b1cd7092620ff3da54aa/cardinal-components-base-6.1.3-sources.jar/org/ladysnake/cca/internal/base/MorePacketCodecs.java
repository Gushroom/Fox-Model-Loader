/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2025 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.internal.base;

import com.mojang.datafixers.util.Unit;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.minecraft.class_1923;
import net.minecraft.class_2540;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class MorePacketCodecs {
    public static final class_9139<ByteBuf, Unit> EMPTY = class_9139.method_56431(Unit.INSTANCE);

    public static final class_9139<class_9129, class_9129> REG_BYTE_BUF = class_9139.method_56437(
        (buf, value) -> {
            buf.method_10804(value.readableBytes());
            buf.method_52975(value);
        },
        (buf) -> {
            int readableBytes = buf.method_10816();
            ByteBuf copy = Unpooled.buffer(readableBytes, readableBytes);
            buf.method_52957(copy, readableBytes);
            return new class_9129(copy, buf.method_56349());
        }
    );

    /**
     * A codec for a {@link class_1923}.
     *
     * @see class_2540#method_36133()
     * @see class_2540#method_36130(class_1923)
     */
    public static final class_9139<class_2540, class_1923> CHUNKPOS = class_9139.method_56437(
        class_2540::method_36130,
        class_2540::method_36133
    );
}
