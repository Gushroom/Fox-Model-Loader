/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2025 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.mixin.base;

import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.ladysnake.cca.api.v3.component.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;

@Mixin(Component.class)
public interface ComponentMixin {
    @Unique
    void readFromNbt(class_2487 tag);
    @Unique
    void writeToNbt(class_2487 tag);

    /**
     * @author Pyrofab
     * @reason binary compatibility with mods released for beta.1
     */
    @Overwrite
    default void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        readFromNbt(tag);
    }

    /**
     * @author Pyrofab
     * @reason binary compatibility with mods released for beta.1
     */
    @Overwrite
    default void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        writeToNbt(tag);
    }
}
