/*
 * Cardinal-Components-API
 * Copyright (C) 2019-2025 Ladysnake
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.ladysnake.cca.api.v3.component.sync;

import net.fabricmc.api.EnvType;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_9129;
import org.jetbrains.annotations.Contract;
import org.ladysnake.cca.api.v3.component.Component;
import org.ladysnake.cca.api.v3.component.ComponentKey;
import org.ladysnake.cca.api.v3.util.CheckEnvironment;

/**
 * A {@link Component} implementing this interface will have its data automatically
 * synchronized with players watching its provider.
 *
 * @see ComponentKey#sync(Object)
 */
public interface AutoSyncedComponent extends Component, ComponentPacketWriter, PlayerSyncPredicate {

    /**
     * Returns {@code true} if a synchronization packet for this component
     * should be immediately sent to {@code player}.
     *
     * @param player potential recipient of a synchronization packet
     * @return {@code true} if synchronization with the {@code player} should occur,
     * {@code false} otherwise
     */
    @Override
    default boolean shouldSyncWith(class_3222 player) {
        return true;
    }

    /**
     * Writes this component's data to {@code buf}.
     *
     * <p>Implementations may choose to change the data written to the packet based on the {@code recipient}
     * or on the {@code syncOp}, or they may safely ignore both parameters.
     * A {@code syncOp} value of {@code 0} triggers the base full synchronization behaviour.
     * Other values have a meaning specific to the component implementation.
     * Typical uses of this parameter include limiting the amount of data being synced (eg. by identifying a
     * specific field to write), or triggering different events on the client (similar to {@link class_1937#method_8421(class_1297, byte)})
     *
     * @param buf       the buffer to write the data to
     * @param recipient the player to which the packet will be sent
     * @implSpec The default implementation writes the whole NBT representation
     * of this component to the buffer using {@link Component#writeToNbt(class_2487, class_7874)}.
     * @implNote The default implementation should generally be overridden.
     * The serialization done by the default implementation sends possibly hidden
     * information to clients, uses a wasteful data format, and does not support
     * any optimization such as incremental updates. Implementing classes can
     * nearly always provide a better implementation.
     * @see ComponentKey#sync(Object)
     * @see ComponentKey#sync(Object, ComponentPacketWriter)
     * @see #applySyncPacket(class_9129)
     */
    @Contract(mutates = "param1")
    @Override
    default void writeSyncPacket(class_9129 buf, class_3222 recipient) {
        class_2487 tag = new class_2487();
        this.writeToNbt(tag, buf.method_56349());
        buf.method_10794(tag);
    }

    /**
     * Reads this component's data from {@code buf}.
     *
     * @implSpec The default implementation converts the buffer's content
     * to a {@link class_2487} and calls {@link Component#readFromNbt(class_2487, class_7874)}.
     * @implNote any implementing class overriding {@link #writeSyncPacket(class_9129, class_3222)}
     * such that it uses a different data format must override this method.
     * @see #writeSyncPacket(class_9129, class_3222)
     */
    @CheckEnvironment(EnvType.CLIENT)
    default void applySyncPacket(class_9129 buf) {
        class_2487 tag = buf.method_10798();
        if (tag != null) {
            this.readFromNbt(tag, buf.method_56349());
        }
    }
}
